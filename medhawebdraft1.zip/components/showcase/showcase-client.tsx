"use client"

import { useState, useCallback } from "react"
import Image from "next/image"
import { Tag } from "@/components/tag"
import {
  showcaseImages,
  categories,
  type ShowcaseCategory,
} from "@/lib/showcase-data"
import { Lightbox } from "@/components/showcase/lightbox"

export function ShowcaseClient() {
  const [activeFilter, setActiveFilter] = useState<ShowcaseCategory>("All")
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null)

  const filtered =
    activeFilter === "All"
      ? showcaseImages
      : showcaseImages.filter((img) => img.category === activeFilter)

  const openLightbox = useCallback((index: number) => {
    setLightboxIndex(index)
  }, [])

  const closeLightbox = useCallback(() => {
    setLightboxIndex(null)
  }, [])

  const goNext = useCallback(() => {
    setLightboxIndex((prev) =>
      prev !== null ? (prev + 1) % filtered.length : null
    )
  }, [filtered.length])

  const goPrev = useCallback(() => {
    setLightboxIndex((prev) =>
      prev !== null ? (prev - 1 + filtered.length) % filtered.length : null
    )
  }, [filtered.length])

  return (
    <>
      {/* Filters */}
      <div className="mb-10 flex flex-wrap gap-2">
        {categories.map((cat) => (
          <Tag
            key={cat}
            active={activeFilter === cat}
            onClick={() => setActiveFilter(cat)}
          >
            {cat}
          </Tag>
        ))}
      </div>

      {/* Grid */}
      <div className="grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((img, i) => (
          <button
            key={img.filename}
            onClick={() => openLightbox(i)}
            className="group relative aspect-[4/3] overflow-hidden bg-muted"
            aria-label={`View ${img.title}`}
          >
            <Image
              src={img.filename}
              alt={img.title}
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-105"
              sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
              unoptimized
            />
            <div className="absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-foreground/90 via-foreground/40 to-transparent p-4 opacity-0 transition-opacity group-hover:opacity-100">
              <span className="font-mono text-[10px] uppercase tracking-wider text-accent">
                {img.relatedProject || img.category}
              </span>
              <p className="mt-1 text-sm font-medium text-primary-foreground">
                {img.title}
              </p>
              {img.commentary && (
                <p className="mt-2 text-xs leading-relaxed text-primary-foreground/70">
                  {img.commentary}
                </p>
              )}
            </div>
          </button>
        ))}
      </div>

      {/* Lightbox */}
      {lightboxIndex !== null && (
        <Lightbox
          image={filtered[lightboxIndex]}
          onClose={closeLightbox}
          onNext={goNext}
          onPrev={goPrev}
          current={lightboxIndex + 1}
          total={filtered.length}
        />
      )}
    </>
  )
}
