"use client"

import { useEffect } from "react"
import Image from "next/image"
import { X, ChevronLeft, ChevronRight } from "lucide-react"
import type { ShowcaseImage } from "@/lib/showcase-data"

interface LightboxProps {
  image: ShowcaseImage
  onClose: () => void
  onNext: () => void
  onPrev: () => void
  current: number
  total: number
}

export function Lightbox({
  image,
  onClose,
  onNext,
  onPrev,
  current,
  total,
}: LightboxProps) {
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose()
      if (e.key === "ArrowRight") onNext()
      if (e.key === "ArrowLeft") onPrev()
    }
    document.addEventListener("keydown", handleKey)
    document.body.style.overflow = "hidden"
    return () => {
      document.removeEventListener("keydown", handleKey)
      document.body.style.overflow = ""
    }
  }, [onClose, onNext, onPrev])

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-foreground/95 p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label={`Showcase image: ${image.title}`}
    >
      {/* Close */}
      <button
        onClick={onClose}
        className="absolute right-4 top-4 z-10 text-primary-foreground transition-opacity hover:opacity-70"
        aria-label="Close lightbox"
      >
        <X className="h-6 w-6" />
      </button>

      {/* Counter */}
      <span className="absolute left-4 top-4 font-mono text-xs text-primary-foreground/60">
        {String(current).padStart(2, "0")} / {String(total).padStart(2, "0")}
      </span>

      {/* Prev */}
      <button
        onClick={(e) => {
          e.stopPropagation()
          onPrev()
        }}
        className="absolute left-4 top-1/2 -translate-y-1/2 text-primary-foreground transition-opacity hover:opacity-70"
        aria-label="Previous image"
      >
        <ChevronLeft className="h-8 w-8" />
      </button>

      {/* Image */}
      <div
        className="relative flex h-[80vh] w-full max-w-5xl flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative flex-1">
          <Image
            src={image.filename}
            alt={image.title}
            fill
            className="object-contain"
            sizes="100vw"
            priority
            unoptimized
          />
        </div>

        {/* Caption with commentary */}
        <div className="mt-4 text-center">
          {image.relatedProject && (
            <span className="font-mono text-[10px] uppercase tracking-wider text-accent">
              {image.relatedProject}
            </span>
          )}
          <p className="mt-1 text-sm font-medium text-primary-foreground">
            {image.title}
          </p>
          {image.commentary && (
            <p className="mx-auto mt-2 max-w-xl text-xs leading-relaxed text-primary-foreground/70">
              {image.commentary}
            </p>
          )}
          <span className="mt-1 text-[10px] uppercase tracking-wider text-primary-foreground/40">
            {image.category}
          </span>
        </div>
      </div>

      {/* Next */}
      <button
        onClick={(e) => {
          e.stopPropagation()
          onNext()
        }}
        className="absolute right-4 top-1/2 -translate-y-1/2 text-primary-foreground transition-opacity hover:opacity-70"
        aria-label="Next image"
      >
        <ChevronRight className="h-8 w-8" />
      </button>
    </div>
  )
}
