"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useState } from "react"
import { Menu, X, Users } from "lucide-react"

const navLinks = [
  { href: "/about", label: "About", num: "01" },
  { href: "/projects", label: "Projects", num: "02" },
  { href: "/showcase", label: "Showcase", num: "03" },
]

export function Navbar() {
  const pathname = usePathname()
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 border-b-[1.5px] border-foreground bg-background">
      <nav className="flex items-stretch">
        {/* Logo */}
        <Link
          href="/"
          className="flex items-center gap-2.5 border-r-[1.5px] border-foreground px-6 py-4 lg:px-8"
        >
          <span className="inline-block h-4 w-4 bg-accent" aria-hidden="true" />
          <span className="font-sans text-base font-bold uppercase tracking-wide text-foreground">
            Medha Academy
          </span>
        </Link>

        {/* Desktop nav links */}
        <div className="hidden flex-1 items-stretch md:flex">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`flex flex-1 items-center justify-center border-r-[1.5px] border-foreground font-mono text-xs uppercase tracking-widest transition-colors ${
                pathname === link.href
                  ? "text-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {"[" + link.num + "] " + link.label}
            </Link>
          ))}

          {/* Join CTA */}
          <Link
            href="/programs"
            className="flex items-center justify-center gap-2 bg-accent px-8 font-mono text-xs uppercase tracking-widest text-accent-foreground transition-opacity hover:opacity-90"
          >
            <Users className="h-3.5 w-3.5" />
            Join Medha Academy
          </Link>
        </div>

        {/* Mobile menu button */}
        <button
          className="ml-auto flex items-center px-6 md:hidden"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label={mobileOpen ? "Close menu" : "Open menu"}
        >
          {mobileOpen ? (
            <X className="h-5 w-5 text-foreground" />
          ) : (
            <Menu className="h-5 w-5 text-foreground" />
          )}
        </button>
      </nav>

      {/* Mobile nav */}
      {mobileOpen && (
        <div className="border-t-[1.5px] border-foreground bg-background px-6 py-6 md:hidden">
          <div className="flex flex-col gap-4">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className={`font-mono text-xs uppercase tracking-widest ${
                  pathname === link.href
                    ? "text-foreground"
                    : "text-muted-foreground"
                }`}
              >
                {"[" + link.num + "] " + link.label}
              </Link>
            ))}
            <Link
              href="/programs"
              onClick={() => setMobileOpen(false)}
              className="mt-2 flex items-center justify-center gap-2 bg-accent px-4 py-3 font-mono text-xs uppercase tracking-widest text-accent-foreground"
            >
              <Users className="h-3.5 w-3.5" />
              Join Medha Academy
            </Link>
          </div>
        </div>
      )}
    </header>
  )
}
