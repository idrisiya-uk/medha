"use client"

import { CheckSquare } from "lucide-react"
import { useReveal } from "@/hooks/use-reveal"

const principles = [
  {
    title: "Truth Over Status",
    desc: "We do not care who you are, only what is true.",
  },
  {
    title: "Skill Over Talk",
    desc: "Demonstrated ability is the only currency.",
  },
  {
    title: "Beauty Before Performance",
    desc: "We optimize for aesthetic and moral truth, not metrics.",
  },
  {
    title: "Discipline Without Ego",
    desc: "Hard work is expected. Humility is mandatory.",
  },
  {
    title: "Community Over Individualism",
    desc: "The strength of the wolf is the pack.",
  },
  {
    title: "No Freeloading",
    desc: "High signal only. Contribute or leave.",
  },
]

export function CorePrinciples() {
  const revealRef = useReveal()

  return (
    <section ref={revealRef} className="section-divider bg-foreground text-primary-foreground">
      {/* Section label */}
      <div className="px-6 pt-12 lg:px-12">
        <span className="reveal font-mono text-[11px] uppercase tracking-widest text-accent">
          {"/// Core Principles"}
        </span>
      </div>

      {/* Principles grid */}
      <div className="grid grid-cols-1 gap-y-8 px-6 py-10 sm:grid-cols-2 lg:px-12 lg:py-14">
        {principles.map((p) => (
          <div key={p.title} className="reveal flex items-start gap-4">
            <CheckSquare className="mt-0.5 h-5 w-5 shrink-0 text-accent" />
            <div>
              <h4 className="font-sans text-sm font-bold uppercase tracking-wide text-primary-foreground">
                {p.title}
              </h4>
              <p className="mt-1 font-sans text-sm text-primary-foreground/60">
                {p.desc}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
