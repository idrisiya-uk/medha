"use client"

import { Calendar } from "lucide-react"
import { useReveal } from "@/hooks/use-reveal"

const sessions = [
  {
    num: "01",
    title: "Intellect Night",
    type: "Discussion & Debate",
  },
  {
    num: "02",
    title: "Creation Night",
    type: "Deep Work / Studio",
  },
  {
    num: "03",
    title: "Body & Brotherhood",
    type: "Physical Training",
  },
  {
    num: "04",
    title: "City Outing",
    type: "Exploration",
  },
]

export function WeeklyCadence() {
  const revealRef = useReveal()

  return (
    <section ref={revealRef} className="section-divider bg-card px-6 py-12 lg:px-12 lg:py-16">
      {/* Header */}
      <div className="reveal flex items-center gap-3">
        <Calendar className="h-6 w-6 text-foreground" strokeWidth={1.5} />
        <h2 className="font-sans text-2xl font-bold uppercase tracking-wide text-foreground md:text-3xl">
          Weekly Cadence
        </h2>
      </div>

      {/* Session rows */}
      <div className="mt-10">
        <div className="border-t-[1.5px] border-accent" />
        {sessions.map((session) => (
          <div
            key={session.num}
            className="reveal flex items-center justify-between border-b-[1.5px] border-foreground py-5"
          >
            <div className="flex items-center gap-6 md:gap-10">
              <span className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
                Session {session.num}
              </span>
              <h3 className="font-sans text-sm font-bold uppercase tracking-wide text-foreground md:text-base">
                {session.title}
              </h3>
            </div>
            <span className="hidden font-mono text-[11px] tracking-widest text-muted-foreground sm:block">
              {session.type}
            </span>
          </div>
        ))}
      </div>
    </section>
  )
}
