"use client"

import Link from "next/link"
import { Users, ClipboardEdit, Handshake } from "lucide-react"
import { useReveal } from "@/hooks/use-reveal"

const paths = [
  {
    icon: Users,
    title: "Attend an Event",
    desc: "The first step. Observe the culture and meet the people.",
    cta: "View Calendar",
    href: "/gallery",
  },
  {
    icon: ClipboardEdit,
    title: "Apply to Circle",
    desc: "For serious members ready for commitment and growth.",
    cta: "Start Application",
    href: "/programs",
  },
  {
    icon: Handshake,
    title: "Collaborate",
    desc: "For builders and creators looking for project deployment.",
    cta: "Pitch Project",
    href: "/projects",
  },
]

export function HowToJoin() {
  const revealRef = useReveal()

  return (
    <section
      ref={revealRef}
      className="section-divider grid grid-cols-1 md:grid-cols-3"
    >
      {paths.map((path, i) => {
        const Icon = path.icon
        return (
          <div
            key={path.title}
            className={`reveal flex flex-col justify-between bg-secondary p-8 lg:p-10 ${
              i < paths.length - 1
                ? "border-b-[1.5px] border-foreground md:border-b-0 md:border-r-[1.5px]"
                : ""
            }`}
          >
            <div>
              <Icon className="h-7 w-7 text-foreground" strokeWidth={1.5} />
              <h3 className="mt-6 font-sans text-base font-bold uppercase tracking-wide text-foreground">
                {path.title}
              </h3>
              <p className="mt-2 font-sans text-sm leading-relaxed text-muted-foreground">
                {path.desc}
              </p>
            </div>
            <Link
              href={path.href}
              className="mt-6 inline-block font-mono text-xs uppercase tracking-widest text-foreground underline underline-offset-4"
            >
              {path.cta}
            </Link>
          </div>
        )
      })}
    </section>
  )
}
