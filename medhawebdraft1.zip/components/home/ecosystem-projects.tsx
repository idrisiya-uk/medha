"use client"

import Link from "next/link"
import {
  Paintbrush,
  Video,
  PenTool,
  BookOpen,
  Rocket,
  MapPin,
  Map,
  Globe,
  Lightbulb,
  Swords,
  Atom,
} from "lucide-react"
import { useReveal } from "@/hooks/use-reveal"

const projects = [
  {
    name: "Creative Glade",
    desc: "Physical creation and contemplation space. Art, craft, beauty, play, quiet work, gatherings.",
    status: "ACTIVE" as const,
    icon: Paintbrush,
    href: "/projects#creative-glade",
  },
  {
    name: "Video Sans",
    desc: "Guild for editors and creators. Skill first, taste driven, anti-commercial.",
    status: "ACTIVE" as const,
    icon: Video,
    href: "/projects#video-sans",
  },
  {
    name: "Platonic Dhaka",
    desc: "Op-ed and narrative engine for social and cultural clarity.",
    status: "ACTIVE" as const,
    icon: PenTool,
    href: "/projects#platonic-dhaka",
  },
  {
    name: "Alexandria",
    desc: "Structured lifelong learning. Reading circles, epistemic discipline, curricula.",
    status: "ACTIVE" as const,
    icon: BookOpen,
    href: "/projects#alexandria",
  },
  {
    name: "Startup Club",
    desc: "Community of startup enthusiasts. Building tools, sharing resources, and launching ventures.",
    status: "ACTIVE" as const,
    icon: Rocket,
    href: "/projects#startup-club",
  },
  {
    name: "Politikos Map",
    desc: "Open source map to track crime and corruption among crucial institutions.",
    status: "ACTIVE" as const,
    icon: MapPin,
    href: "/projects#politikos-map",
  },
  {
    name: "Dhaka Scouts",
    desc: "Weekly human-scale urban exploration and documentation of the city.",
    status: "ACTIVE" as const,
    icon: Map,
    href: "/projects#dhaka-scouts",
  },
  {
    name: "Prosno Show",
    desc: "Public Socratic inquiry, street questions, long-form dialogues.",
    status: "ACTIVE" as const,
    icon: Globe,
    href: "/projects#prosno-show",
  },
  {
    name: "Lumina",
    desc: "All female sorority for intellectual sisterhood, women-led social change, and ethics.",
    status: "ACTIVE" as const,
    icon: Lightbulb,
    href: "/projects#lumina",
  },
  {
    name: "Fight Club",
    desc: "Disciplined body plus knowledge. Grappling and principles. Power without corruption.",
    status: "INCUBATING" as const,
    icon: Swords,
    href: "/projects#fight-club",
  },
  {
    name: "Principia",
    desc: "Knowledge community under Alexandria. Personalized intellect paths, unity, care, truth.",
    status: "INCUBATING" as const,
    icon: Atom,
    href: "/projects#principia",
  },
]

export function EcosystemProjects() {
  const revealRef = useReveal()

  return (
    <section ref={revealRef}>
      {/* Divider line above */}
      <div className="section-divider" />

      {/* Header bar */}
      <div className="flex items-center justify-between border-b-[1.5px] border-foreground px-6 py-4 lg:px-8">
        <h2 className="font-sans text-xl font-bold uppercase tracking-wide text-foreground md:text-2xl">
          Ecosystem Projects
        </h2>
        <div className="flex items-center gap-4 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <span className="inline-block h-2 w-2 rounded-full bg-foreground" />
            Active
          </span>
          <span className="flex items-center gap-1.5">
            <span className="inline-block h-2 w-2 rounded-full border border-muted-foreground" />
            Incubating
          </span>
        </div>
      </div>

      {/* Project grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
        {projects.map((project, i) => {
          const Icon = project.icon
          const isActive = project.status === "ACTIVE"
          return (
            <Link
              key={project.name}
              href={project.href}
              className={`reveal group flex flex-col justify-between border-b-[1.5px] border-foreground p-6 transition-all duration-300 hover:bg-foreground hover:text-primary-foreground lg:p-8 ${
                isActive ? "bg-card" : "bg-secondary"
              } ${
                i % 2 === 0 ? "sm:border-r-[1.5px]" : ""
              } ${(i + 1) % 3 !== 0 ? "lg:border-r-[1.5px]" : "lg:border-r-0"}`}
              style={{ transitionDelay: `${(i % 3) * 80}ms` }}
            >
              <div>
                <div className="flex items-start justify-between">
                  <Icon
                    className="h-6 w-6 text-muted-foreground transition-colors duration-300 group-hover:text-primary-foreground"
                    strokeWidth={1.5}
                  />
                  <span
                    className={`border px-2 py-0.5 font-mono text-[10px] uppercase tracking-widest transition-colors duration-300 ${
                      isActive
                        ? "border-foreground text-foreground group-hover:border-primary-foreground group-hover:text-primary-foreground"
                        : "border-muted-foreground text-muted-foreground group-hover:border-primary-foreground/60 group-hover:text-primary-foreground/60"
                    }`}
                  >
                    {project.status}
                  </span>
                </div>
                <h3 className="mt-5 font-sans text-lg font-bold uppercase tracking-wide text-foreground transition-colors duration-300 group-hover:text-primary-foreground">
                  {project.name}
                </h3>
              </div>
              <p className="mt-3 font-sans text-sm leading-relaxed text-muted-foreground transition-colors duration-300 group-hover:text-primary-foreground/70">
                {project.desc}
              </p>
            </Link>
          )
        })}
        {/* Empty cell to complete the grid */}
        <div className="hidden border-b-[1.5px] border-foreground bg-card lg:block" />
      </div>
    </section>
  )
}
