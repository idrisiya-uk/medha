import Link from "next/link"
import Image from "next/image"
import { ArrowDownRight, LogIn } from "lucide-react"

export function HeroSection() {
  return (
    <section className="flex min-h-[calc(100vh-57px)] flex-col lg:flex-row">
      {/* Left: Hero Image */}
      <div className="relative h-[50vh] w-full lg:h-auto lg:w-[68%]">
        <Image
          src="https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=1600&q=80&auto=format&fit=crop"
          alt="Abstract dark architectural geometry"
          fill
          className="object-cover grayscale"
          priority
          crossOrigin="anonymous"
        />
      </div>

      {/* Right: Content — narrower */}
      <div className="flex w-full flex-col justify-between bg-background p-8 lg:w-[32%] lg:p-10">
        {/* Status */}
        <div>
          <div className="flex items-center gap-2 border-b-[1.5px] border-accent pb-4">
            <span className="text-sm text-accent" aria-hidden="true">&#9786;</span>
            <span className="font-mono text-[11px] uppercase tracking-widest text-accent">
              Ecosystem Status: Active
            </span>
          </div>

          {/* Heading — sans-serif bold condensed */}
          <h1 className="mt-8 font-sans text-[2.5rem] font-bold uppercase leading-[0.95] tracking-tight text-foreground md:text-5xl xl:text-[3.5rem]">
            Build the
            <br />
            Self.
            <br />
            Build the
            <br />
            Culture.
          </h1>

          {/* Description — sans-serif */}
          <div className="mt-8">
            <p className="font-sans text-base leading-relaxed text-foreground lg:text-lg">
              Medha Academy is a parallel ecosystem for talent discovery,
              cultivation, alignment, and deployment. We operate outside the
              noise to build the next generation of philosophers, builders and
              thinkers.
            </p>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="mt-12 flex flex-col gap-0">
          <Link
            href="/projects"
            className="group flex items-center justify-between bg-card px-6 py-4 text-foreground transition-colors hover:bg-foreground hover:text-primary-foreground"
          >
            <span className="font-mono text-xs uppercase tracking-widest">
              See Projects
            </span>
            <ArrowDownRight className="h-4 w-4" />
          </Link>
          <Link
            href="/programs"
            className="group flex items-center justify-between bg-accent px-6 py-4 transition-opacity hover:opacity-90"
          >
            <span className="font-mono text-xs uppercase tracking-widest text-accent-foreground">
              Join Medha Academy
            </span>
            <LogIn className="h-4 w-4 text-accent-foreground" />
          </Link>
        </div>
      </div>
    </section>
  )
}
