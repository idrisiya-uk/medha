"use client"

import { Settings } from "lucide-react"
import { useReveal } from "@/hooks/use-reveal"

const steps = [
  {
    num: "01.",
    title: "The Intake",
    description:
      "Enter through the gates via events or content. No resume drops. We observe curiosity, conduct, and questions.",
  },
  {
    num: "02.",
    title: "The Filter",
    description:
      "Rigorous profiling reveals your natural grain. We separate signal from noise. High standards, no freeloading.",
  },
  {
    num: "03.",
    title: "The Deployment",
    description:
      "Placement into a specific project lane. Mentorship, real stakes, and structured work with a brotherhood.",
  },
]

export function OperationalLogic() {
  const revealRef = useReveal()

  return (
    <section ref={revealRef}>
      {/* Divider line above */}
      <div className="section-divider" />

      {/* Label bar — black bg */}
      <div className="flex items-center gap-2 border-b-[1.5px] border-foreground bg-foreground px-6 py-3 lg:px-8">
        <Settings className="h-3.5 w-3.5 text-primary-foreground/50" />
        <span className="font-mono text-[11px] uppercase tracking-widest text-primary-foreground/50">
          Operational Logic
        </span>
      </div>

      {/* 3 columns — bluish light gray */}
      <div className="grid grid-cols-1 border-b-[1.5px] border-foreground md:grid-cols-3">
        {steps.map((step, i) => (
          <div
            key={step.num}
            className={`reveal bg-secondary p-8 lg:p-10 ${
              i < steps.length - 1
                ? "border-b-[1.5px] border-foreground md:border-b-0 md:border-r-[1.5px]"
                : ""
            }`}
          >
            <span className="font-mono text-5xl font-bold text-accent lg:text-6xl">
              {step.num}
            </span>
            <h3 className="mt-4 font-sans text-lg font-bold uppercase tracking-wide text-foreground">
              {step.title}
            </h3>
            <p className="mt-3 font-sans text-sm leading-relaxed text-muted-foreground">
              {step.description}
            </p>
          </div>
        ))}
      </div>
    </section>
  )
}
