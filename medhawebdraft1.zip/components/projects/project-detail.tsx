import type { Project } from "@/lib/projects-data"
import {
  Palette,
  Film,
  BookOpen,
  Library,
  Rocket,
  Map,
  Compass,
  Mic,
  Sun,
  Swords,
  Lightbulb,
} from "lucide-react"

const iconMap: Record<string, React.ElementType> = {
  Palette,
  Film,
  BookOpen,
  Library,
  Rocket,
  Map,
  Compass,
  Mic,
  Sun,
  Swords,
  Lightbulb,
}

interface ProjectDetailProps {
  project: Project
}

export function ProjectDetail({ project }: ProjectDetailProps) {
  const Icon = iconMap[project.icon] || Palette

  return (
    <article id={project.id} className="scroll-mt-28 border-t border-border pt-12">
      <div className="flex items-start gap-4">
        <div className="flex h-10 w-10 items-center justify-center border border-border">
          <Icon className="h-4 w-4 text-muted-foreground" />
        </div>
        <div className="flex-1">
          <div className="flex flex-wrap items-center gap-3">
            <h2 className="text-2xl font-medium text-foreground">
              {project.title}
            </h2>
            {project.incubating && (
              <span className="border border-accent px-2 py-0.5 font-mono text-[10px] uppercase tracking-widest text-accent">
                Incubating
              </span>
            )}
          </div>
          <p className="mt-1 font-sans text-lg italic text-muted-foreground">
            {project.tagline}
          </p>
        </div>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-2">
        <div>
          {project.description.map((paragraph, i) => (
            <p
              key={i}
              className="mt-4 first:mt-0 text-sm leading-relaxed text-muted-foreground"
            >
              {paragraph}
            </p>
          ))}
        </div>

        <div className="flex flex-col gap-8">
          <div>
            <h3 className="font-mono text-xs uppercase tracking-widest text-foreground">
              What we do
            </h3>
            <ul className="mt-3 flex flex-col gap-2">
              {project.whatWeDo.map((item) => (
                <li
                  key={item}
                  className="flex items-start gap-2 text-sm text-muted-foreground"
                >
                  <span className="mt-1.5 h-1 w-1 shrink-0 bg-accent" />
                  {item}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-mono text-xs uppercase tracking-widest text-foreground">
              Who it{"'"}s for
            </h3>
            <ul className="mt-3 flex flex-col gap-2">
              {project.whoItsFor.map((item) => (
                <li
                  key={item}
                  className="flex items-start gap-2 text-sm text-muted-foreground"
                >
                  <span className="mt-1.5 h-1 w-1 shrink-0 bg-accent" />
                  {item}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-mono text-xs uppercase tracking-widest text-foreground">
              How to join
            </h3>
            <ol className="mt-3 flex flex-col gap-2">
              {project.howToJoin.map((step, i) => (
                <li
                  key={step}
                  className="flex items-start gap-3 text-sm text-muted-foreground"
                >
                  <span className="font-mono text-xs text-accent">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  {step}
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>
    </article>
  )
}
