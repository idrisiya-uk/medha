"use client"

import type { Project } from "@/lib/projects-data"

interface ProjectsIndexProps {
  projects: Project[]
}

export function ProjectsIndex({ projects }: ProjectsIndexProps) {
  return (
    <aside className="hidden lg:block lg:w-56 lg:shrink-0">
      <nav className="sticky top-24">
        <h2 className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
          Index
        </h2>
        <ul className="mt-4 flex flex-col gap-1">
          {projects.map((project, i) => (
            <li key={project.id}>
              <a
                href={`#${project.id}`}
                className="group flex items-center gap-3 py-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
              >
                <span className="font-mono text-[10px] text-accent">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span>{project.title}</span>
                {project.incubating && (
                  <span className="ml-auto text-[10px] uppercase tracking-wider text-accent">
                    Inc
                  </span>
                )}
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  )
}
