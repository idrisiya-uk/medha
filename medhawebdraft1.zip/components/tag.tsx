import { cn } from "@/lib/utils"

interface TagProps {
  children: React.ReactNode
  active?: boolean
  onClick?: () => void
  className?: string
}

export function Tag({ children, active = false, onClick, className }: TagProps) {
  const Component = onClick ? "button" : "span"

  return (
    <Component
      onClick={onClick}
      className={cn(
        "inline-flex items-center border px-3 py-1 text-xs uppercase tracking-wider transition-colors",
        active
          ? "border-foreground bg-foreground text-primary-foreground"
          : "border-border bg-transparent text-muted-foreground hover:border-foreground hover:text-foreground",
        className
      )}
    >
      {children}
    </Component>
  )
}
