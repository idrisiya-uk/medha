import Link from "next/link"
import { ArrowUpRight } from "lucide-react"
import { cn } from "@/lib/utils"

interface ProjectCardProps {
  title: string
  tagline: string
  href: string
  incubating?: boolean
  className?: string
}

export function ProjectCard({ title, tagline, href, incubating = false, className }: ProjectCardProps) {
  return (
    <Link
      href={href}
      className={cn(
        "group flex flex-col justify-between border border-border p-6 transition-colors hover:border-foreground",
        className
      )}
    >
      <div>
        <div className="flex items-start justify-between">
          <h3 className="text-lg font-medium text-foreground">{title}</h3>
          <ArrowUpRight className="h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-foreground" />
        </div>
        {incubating && (
          <span className="mt-2 inline-block border border-accent px-2 py-0.5 font-mono text-[10px] uppercase tracking-widest text-accent">
            Incubating
          </span>
        )}
      </div>
      <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{tagline}</p>
    </Link>
  )
}
