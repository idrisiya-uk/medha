import { cn } from "@/lib/utils"

interface SectionProps {
  children: React.ReactNode
  className?: string
  label?: string
  id?: string
}

export function Section({ children, className, label, id }: SectionProps) {
  return (
    <section id={id} className={cn("mx-auto max-w-7xl px-6 py-20 lg:px-8 lg:py-28", className)}>
      {label && (
        <div className="mb-12">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
            {label}
          </span>
          <div className="mt-2 h-px w-12 bg-accent" />
        </div>
      )}
      {children}
    </section>
  )
}
