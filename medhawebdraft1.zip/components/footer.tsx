"use client"

import { Instagram } from "lucide-react"
import { useState } from "react"

export function Footer() {
  const [email, setEmail] = useState("")

  return (
    <footer className="bg-[#000000] text-primary-foreground">
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_2px_1fr]">
        {/* Left column */}
        <div className="flex flex-col justify-between p-8 lg:p-12">
          <h2 className="font-sans text-3xl font-bold uppercase leading-[0.95] tracking-tight text-primary-foreground md:text-4xl xl:text-5xl">
            Build the
            <br />
            Parallel
            <br />
            Institution.
          </h2>

          <div className="mt-12">
            <span className="font-mono text-[11px] uppercase tracking-widest text-primary-foreground/50">
              Join the Signal
            </span>
            <form
              className="mt-3 flex"
              onSubmit={(e) => {
                e.preventDefault()
                setEmail("")
              }}
            >
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="EMAIL ADDRESS"
                className="flex-1 border-[1.5px] border-primary-foreground/20 bg-transparent px-4 py-3 font-mono text-xs uppercase tracking-widest text-primary-foreground placeholder:text-primary-foreground/30 focus:border-primary-foreground focus:outline-none"
              />
              <button
                type="submit"
                className="bg-primary-foreground px-6 py-3 font-sans text-sm font-bold text-foreground transition-opacity hover:opacity-90"
              >
                Submit
              </button>
            </form>
          </div>
        </div>

        {/* Divider */}
        <div className="hidden bg-primary-foreground/10 lg:block" />

        {/* Right column */}
        <div className="flex flex-col justify-between border-t-[1.5px] border-primary-foreground/10 p-8 lg:border-t-0 lg:p-12">
          <div className="grid grid-cols-2 gap-8">
            <div>
              <span className="font-mono text-[10px] uppercase tracking-widest text-primary-foreground/40">
                Operations
              </span>
              <p className="mt-2 font-mono text-xs font-medium tracking-wider text-primary-foreground/80">
                Dhaka, Bangladesh
              </p>
            </div>
            <div>
              <span className="font-mono text-[10px] uppercase tracking-widest text-primary-foreground/40">
                Contact
              </span>
              <p className="mt-2 font-mono text-xs font-medium tracking-wider text-primary-foreground/80">
                medha.acd@gmail.com
              </p>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 inline-block text-primary-foreground/40 transition-colors hover:text-primary-foreground"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div className="mt-12 flex items-center justify-between border-t-[1.5px] border-primary-foreground/10 pt-6">
            <span className="font-mono text-[10px] uppercase tracking-widest text-primary-foreground/40">
              {"© 2024 Medha Academy."}
            </span>
            <span className="font-mono text-[10px] uppercase tracking-widest text-primary-foreground/40">
              Est. 2024
            </span>
          </div>
        </div>
      </div>
    </footer>
  )
}
