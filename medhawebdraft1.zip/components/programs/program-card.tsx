interface Program {
  title: string
  type: string
  price: string
  description: string
  whoItsFor: string[]
  whatYouGet: string[]
  rules: string[]
  steps: string[]
}

interface ProgramCardProps {
  program: Program
}

export function ProgramCard({ program }: ProgramCardProps) {
  return (
    <div className="flex flex-col justify-between bg-background p-8 lg:p-10">
      {/* Header */}
      <div>
        <span className="font-mono text-xs uppercase tracking-widest text-accent">
          {program.type}
        </span>
        <h2 className="mt-3 text-2xl font-medium text-foreground">
          {program.title}
        </h2>
        <p className="mt-1 font-mono text-lg font-bold text-foreground">
          {program.price}
        </p>
        <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
          {program.description}
        </p>

        {/* Who it's for */}
        <div className="mt-8">
          <h3 className="font-mono text-xs uppercase tracking-widest text-foreground">
            Who it{"'"}s for
          </h3>
          <ul className="mt-3 flex flex-col gap-2">
            {program.whoItsFor.map((item) => (
              <li
                key={item}
                className="flex items-start gap-2 text-sm text-muted-foreground"
              >
                <span className="mt-1.5 h-1 w-1 shrink-0 bg-accent" />
                {item}
              </li>
            ))}
          </ul>
        </div>

        {/* What you get */}
        <div className="mt-8">
          <h3 className="font-mono text-xs uppercase tracking-widest text-foreground">
            What you get
          </h3>
          <ul className="mt-3 flex flex-col gap-2">
            {program.whatYouGet.map((item) => (
              <li
                key={item}
                className="flex items-start gap-2 text-sm text-muted-foreground"
              >
                <span className="mt-1.5 h-1 w-1 shrink-0 bg-accent" />
                {item}
              </li>
            ))}
          </ul>
        </div>

        {/* Rules */}
        <div className="mt-8">
          <h3 className="font-mono text-xs uppercase tracking-widest text-foreground">
            Rules / Standards
          </h3>
          <ul className="mt-3 flex flex-col gap-2">
            {program.rules.map((item) => (
              <li
                key={item}
                className="flex items-start gap-2 text-sm text-muted-foreground"
              >
                <span className="mt-1.5 h-1 w-1 shrink-0 bg-foreground" />
                {item}
              </li>
            ))}
          </ul>
        </div>

        {/* Steps */}
        <div className="mt-8">
          <h3 className="font-mono text-xs uppercase tracking-widest text-foreground">
            How to apply
          </h3>
          <ol className="mt-3 flex flex-col gap-2">
            {program.steps.map((step, i) => (
              <li
                key={step}
                className="flex items-start gap-3 text-sm text-muted-foreground"
              >
                <span className="font-mono text-xs text-accent">
                  {String(i + 1).padStart(2, "0")}
                </span>
                {step}
              </li>
            ))}
          </ol>
        </div>
      </div>

      {/* CTA */}
      <a
        href="https://forms.google.com"
        target="_blank"
        rel="noopener noreferrer"
        className="mt-10 block border border-foreground bg-foreground py-3 text-center text-xs uppercase tracking-wider text-primary-foreground transition-colors hover:bg-transparent hover:text-foreground"
      >
        Apply Now
      </a>
    </div>
  )
}
