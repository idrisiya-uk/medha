import type { Metadata } from "next"
import { projects } from "@/lib/projects-data"
import { ProjectsIndex } from "@/components/projects/projects-index"
import { ProjectDetail } from "@/components/projects/project-detail"

export const metadata: Metadata = {
  title: "Projects | Medha Academy",
  description: "Explore all active and incubating projects within the Medha ecosystem.",
}

export default function ProjectsPage() {
  return (
    <div className="mx-auto max-w-7xl px-6 py-20 lg:px-8 lg:py-28">
      <div className="mb-16">
        <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
          All Projects
        </span>
        <div className="mt-2 h-px w-12 bg-accent" />
        <h1 className="mt-8 font-serif text-4xl text-foreground md:text-5xl">
          The Ecosystem
        </h1>
        <p className="mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">
          Every project is a lane. A structured space for serious work. Browse the
          full directory below, or jump to a specific project using the index.
        </p>
      </div>

      <div className="flex flex-col gap-16 lg:flex-row lg:gap-20">
        {/* Sticky sidebar index */}
        <ProjectsIndex projects={projects} />

        {/* Project sections */}
        <div className="flex-1">
          <div className="flex flex-col gap-24">
            {projects.map((project) => (
              <ProjectDetail key={project.id} project={project} />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
