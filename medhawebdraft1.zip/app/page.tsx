import { HeroSection } from "@/components/home/hero-section"
import { OperationalLogic } from "@/components/home/operational-logic"
import { EcosystemProjects } from "@/components/home/ecosystem-projects"
import { CorePrinciples } from "@/components/home/core-principles"
import { WeeklyCadence } from "@/components/home/weekly-cadence"
import { HowToJoin } from "@/components/home/how-to-join"

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <OperationalLogic />
      <EcosystemProjects />
      <WeeklyCadence />
      <HowToJoin />
      <CorePrinciples />
    </>
  )
}
