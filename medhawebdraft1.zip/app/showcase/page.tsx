import type { Metadata } from "next"
import { ShowcaseClient } from "@/components/showcase/showcase-client"

export const metadata: Metadata = {
  title: "Showcase | Medha Academy",
  description:
    "A visual record of projects, events, spaces, and people from the Medha ecosystem.",
}

export default function ShowcasePage() {
  return (
    <div className="mx-auto max-w-7xl px-6 py-20 lg:px-8 lg:py-28">
      <div className="mb-16">
        <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
          Showcase
        </span>
        <div className="mt-2 h-px w-12 bg-accent" />
        <h1 className="mt-8 font-sans text-4xl font-bold uppercase tracking-tight text-foreground md:text-5xl">
          Visual Record
        </h1>
        <p className="mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">
          Projects, events, spaces, and people from across the Medha ecosystem.
        </p>
      </div>

      <ShowcaseClient />

      <div className="mt-16 border-t-[1.5px] border-border pt-12 text-center">
        <p className="text-sm text-muted-foreground">
          Have images to contribute?
        </p>
        <a
          href="https://forms.google.com"
          target="_blank"
          rel="noopener noreferrer"
          className="mt-4 inline-block border-[1.5px] border-foreground bg-foreground px-6 py-3 font-mono text-xs uppercase tracking-wider text-primary-foreground transition-colors hover:bg-transparent hover:text-foreground"
        >
          Submit to Showcase
        </a>
      </div>
    </div>
  )
}
