import type { Metadata } from "next"
import Image from "next/image"
import Link from "next/link"

export const metadata: Metadata = {
  title: "About | Medha Academy",
  description:
    "The Medha Academy Wiki is a comprehensive knowledge system documenting the intellectual foundations, educational methods, and applied projects.",
}

export default function AboutPage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="section-divider border-b-[1.5px] border-foreground bg-secondary px-6 py-20 lg:px-8 lg:py-28">
        <div className="mx-auto max-w-4xl">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
            About
          </span>
          <h1 className="mt-4 font-sans text-4xl font-bold uppercase leading-tight tracking-tight text-foreground md:text-5xl lg:text-6xl">
            The Medha Academy Wiki
          </h1>
          <p className="mt-6 text-lg leading-relaxed text-foreground">
            A comprehensive knowledge system documenting the intellectual
            foundations, educational methods, cultural activities, research
            practices, and applied projects developed under Medha Academy.
          </p>
        </div>
      </section>

      {/* Content Grid with Images */}
      <section className="grid grid-cols-1 lg:grid-cols-2">
        {/* Left: Image 1 */}
        <div className="relative aspect-[4/3] lg:aspect-auto">
          <Image
            src="/images/about-abstract-01.jpg"
            alt="Abstract architectural forms"
            fill
            className="object-cover"
            sizes="(max-width: 1024px) 100vw, 50vw"
          />
        </div>

        {/* Right: Foundation Text */}
        <div className="border-b-[1.5px] border-foreground bg-card p-8 lg:border-l-[1.5px] lg:p-16">
          <h2 className="font-sans text-2xl font-bold uppercase tracking-tight text-foreground">
            Foundation
          </h2>
          <p className="mt-6 leading-relaxed text-foreground">
            It presents Medha Academy as a complete system, ranging from
            metaphysical principles and theories of knowledge to practical
            action, skill formation, economic activity, and institution-building.
          </p>
          <p className="mt-4 leading-relaxed text-foreground">
            The academy's approach is informed by contemporary institutional
            research, including work recognized by the 2024 Nobel Prize in
            Economics, which demonstrated that durable societies depend on
            principle-based institutions rather than self-interested or
            extractive structures.
          </p>
          <p className="mt-4 leading-relaxed text-foreground">
            These principles are not new. They draw from intellectual traditions
            that have remained functional for thousands of years because they
            reflect enduring truths about human psychology, social order, and
            moral formation, articulated by thinkers such as Plato, Aristotle,
            and later classical scholars.
          </p>
        </div>

        {/* Left: System Text */}
        <div className="border-b-[1.5px] border-foreground bg-secondary p-8 lg:p-16">
          <h2 className="font-sans text-2xl font-bold uppercase tracking-tight text-foreground">
            How The System Works
          </h2>
          <p className="mt-6 leading-relaxed text-foreground">
            This system operates as an ecosystem of people, activities, and
            projects rather than a single rigid institution. It is not
            structured like a typical organization with fixed roles, permanent
            positions, or uniform progression.
          </p>
          <p className="mt-4 leading-relaxed text-foreground">
            Instead, it functions through continuous observation, judgment, and
            testing in practice. Participation is shaped by how a person thinks,
            acts, responds to responsibility, and follows through over time.
          </p>
          <div className="mt-6 space-y-3">
            <div className="flex items-start gap-3">
              <span className="mt-1 inline-block h-1.5 w-1.5 flex-shrink-0 bg-accent" />
              <p className="text-sm leading-relaxed text-foreground">
                All work happens through projects, not abstract membership
              </p>
            </div>
            <div className="flex items-start gap-3">
              <span className="mt-1 inline-block h-1.5 w-1.5 flex-shrink-0 bg-accent" />
              <p className="text-sm leading-relaxed text-foreground">
                Responsibility increases only through demonstrated action and
                consistency
              </p>
            </div>
          </div>
        </div>

        {/* Right: Image 2 */}
        <div className="relative aspect-[4/3] lg:aspect-auto">
          <Image
            src="/images/about-abstract-02.jpg"
            alt="Minimal geometric architectural forms"
            fill
            className="object-cover"
            sizes="(max-width: 1024px) 100vw, 50vw"
          />
        </div>

        {/* Full Width: Participation */}
        <div className="border-b-[1.5px] border-foreground bg-card p-8 lg:col-span-2 lg:p-16">
          <div className="mx-auto max-w-4xl">
            <h2 className="font-sans text-2xl font-bold uppercase tracking-tight text-foreground">
              Participation and Matching
            </h2>
            <p className="mt-6 leading-relaxed text-foreground">
              Everything happens through projects. Some are light and
              exploratory, others demand consistency and responsibility.
              Participation naturally varies in depth, and deeper involvement is
              earned through action rather than titles or formal roles.
            </p>
            <p className="mt-4 leading-relaxed text-foreground">
              People also contribute in different ways. Broadly, contributions
              tend to lean toward thinking and principles, social coordination,
              or building and making. These are not fixed identities, but
              practical orientations used to reduce mismatch and friction.
            </p>
            <p className="mt-4 leading-relaxed text-foreground">
              Matching happens by aligning three simple factors: what a project
              requires, what a person is naturally suited to do, and how much
              responsibility that person can realistically carry at a given time.
            </p>
          </div>
        </div>

        {/* Full Width: Continuity */}
        <div className="bg-foreground p-8 text-primary-foreground lg:col-span-2 lg:p-16">
          <div className="mx-auto max-w-4xl">
            <h2 className="font-sans text-2xl font-bold uppercase tracking-tight">
              Continuity and Purpose
            </h2>
            <p className="mt-6 leading-relaxed">
              Some work within the ecosystem produces value that can support
              continuity through services, events, media output, or applied
              creative and technical work. This economic layer exists to keep
              the work alive, not to replace its purpose.
            </p>
            <p className="mt-4 leading-relaxed">
              The aim is coherence between knowledge, practice, and real-world
              action, without collapsing into chaos or bureaucracy.
            </p>
            <div className="mt-12 text-center">
              <Link
                href="/projects"
                className="inline-block border-[1.5px] border-primary-foreground px-8 py-4 font-mono text-xs uppercase tracking-widest transition-colors hover:bg-primary-foreground hover:text-foreground"
              >
                Explore Projects
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
