import type { Metadata } from "next"
import { ProgramCard } from "@/components/programs/program-card"

export const metadata: Metadata = {
  title: "Paid Programs | Medha Academy",
  description:
    "Join The Circle, The Guild, or The Studio Pass. Limited seats, filtered for seriousness.",
}

const programs = [
  {
    title: "The Circle",
    type: "Monthly Membership",
    price: "BDT 1,500/mo",
    description:
      "An inner ring of committed members who get priority access to all Medha projects, events, and mentorship channels. This is not a subscription box. It is a commitment.",
    whoItsFor: [
      "Individuals who want deep, ongoing involvement in the ecosystem",
      "Creators, thinkers, and builders who show up consistently",
      "People who see value in structured community",
    ],
    whatYouGet: [
      "Priority access to all Medha project lanes",
      "Monthly 1-on-1 mentorship sessions",
      "Exclusive member-only events and salons",
      "Voting rights on community decisions",
    ],
    rules: [
      "Attend at least 2 events per month",
      "Contribute to at least one project actively",
      "No passive consumption. You produce, or you leave.",
    ],
    steps: [
      "Fill out the application form",
      "Complete an intake interview",
      "Receive approval and begin onboarding",
    ],
  },
  {
    title: "The Guild",
    type: "Skill Track + Project Work",
    price: "BDT 5,000/track",
    description:
      "A structured skill-building program where you learn by doing. Each track is 8 weeks, project-based, and ends with a real deliverable. No certificates. Just proof of work.",
    whoItsFor: [
      "Beginners and intermediates who want structured skill development",
      "People who learn best by shipping real things",
      "Aspiring professionals in design, writing, filmmaking, or research",
    ],
    whatYouGet: [
      "8-week guided track in a specific discipline",
      "Weekly assignments with mentor feedback",
      "A final project for your portfolio",
      "Access to peer cohort for collaboration",
    ],
    rules: [
      "Complete all weekly assignments on time",
      "No ghosting. If life happens, communicate.",
      "Final project must be submitted to complete the track",
    ],
    steps: [
      "Choose a track from available disciplines",
      "Submit an application with your background and goals",
      "Pay the track fee upon acceptance",
      "Begin your 8-week journey",
    ],
  },
  {
    title: "The Studio Pass",
    type: "Space + Sessions",
    price: "BDT 3,000/mo",
    description:
      "Physical access to the Medha studio space in Dhaka, plus weekly drop-in sessions on various topics. A third place for people who need one.",
    whoItsFor: [
      "Independent workers, freelancers, and students who need a focused space",
      "People looking for serendipitous encounters with interesting minds",
      "Anyone who thrives in shared physical environments",
    ],
    whatYouGet: [
      "Unlimited daytime access to the Medha studio space",
      "Weekly drop-in workshops and skill sessions",
      "Use of shared equipment and resources",
      "Coffee. Always coffee.",
    ],
    rules: [
      "Respect the space: clean up after yourself",
      "No loud phone calls in the quiet zone",
      "Contribute to at least one community session per month",
    ],
    steps: [
      "Visit the space during open hours for a tour",
      "Fill out the Studio Pass application",
      "Pay the monthly pass fee",
      "Get your access and welcome kit",
    ],
  },
]

export default function ProgramsPage() {
  return (
    <div className="mx-auto max-w-7xl px-6 py-20 lg:px-8 lg:py-28">
      <div className="mb-16">
        <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
          Paid Programs
        </span>
        <div className="mt-2 h-px w-12 bg-accent" />
        <h1 className="mt-8 font-serif text-4xl text-foreground md:text-5xl">
          Invest in Yourself
        </h1>
        <p className="mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">
          Three programs, each designed for a different level of engagement. All
          filtered for seriousness. No passive observers.
        </p>
      </div>

      <div className="grid gap-px bg-border lg:grid-cols-3">
        {programs.map((program) => (
          <ProgramCard key={program.title} program={program} />
        ))}
      </div>

      <div className="mt-16 border border-border p-8 text-center lg:p-12">
        <p className="font-mono text-xs uppercase tracking-widest text-accent">
          Notice
        </p>
        <p className="mx-auto mt-4 max-w-lg text-lg font-medium text-foreground">
          Limited seats. We filter for seriousness.
        </p>
        <p className="mt-2 text-sm text-muted-foreground">
          Every application is reviewed. We don{"'"}t accept everyone. If you{"'"}re
          here for clout, look elsewhere.
        </p>
      </div>
    </div>
  )
}
