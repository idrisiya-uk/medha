export type ShowcaseCategory = "All" | "Projects" | "Events" | "Spaces" | "People"

export interface ShowcaseImage {
  filename: string
  title: string
  category: Exclude<ShowcaseCategory, "All">
  commentary?: string
  relatedProject?: string
}

export const showcaseImages: ShowcaseImage[] = [
  {
    filename: "https://images.unsplash.com/photo-1513001900722-370f803f498d?w=1600&q=80",
    title: "Creative Glade Workshop",
    category: "Projects",
    commentary: "A physical creation session at the Creative Glade space. Art, craft, beauty, play, quiet work, gatherings.",
    relatedProject: "Creative Glade",
  },
  {
    filename: "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=1600&q=80",
    title: "Video Sans Editing Session",
    category: "Projects",
    commentary: "Guild members working on editorial content. Skill-first, taste-driven, anti-commercial.",
    relatedProject: "Video Sans",
  },
  {
    filename: "https://images.unsplash.com/photo-1515187029135-18ee286d815b?w=1600&q=80",
    title: "Platonic Dhaka Discussion",
    category: "Projects",
    commentary: "Weekly op-ed sessions analyzing social and cultural issues through philosophical frameworks.",
    relatedProject: "Platonic Dhaka",
  },
  {
    filename: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=1600&q=80",
    title: "Alexandria Reading Circle",
    category: "Projects",
    commentary: "Structured lifelong learning through curated reading circles and epistemic discipline.",
    relatedProject: "Alexandria",
  },
  {
    filename: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=1600&q=80",
    title: "Startup Club Meetup",
    category: "Projects",
    commentary: "Community of builders sharing tools, resources, and launching ventures together.",
    relatedProject: "Startup Club",
  },
  {
    filename: "https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=1600&q=80",
    title: "Dhaka Scouts Urban Exploration",
    category: "Projects",
    commentary: "Weekly human-scale urban exploration documenting the city's evolving landscape.",
    relatedProject: "Dhaka Scouts",
  },
  {
    filename: "https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=1600&q=80",
    title: "Prosno Show Session",
    category: "Events",
    commentary: "Public Socratic inquiry—street questions, long-form dialogues on camera.",
    relatedProject: "Prosno Show",
  },
  {
    filename: "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=1600&q=80",
    title: "Lumina Women's Gathering",
    category: "Events",
    commentary: "All-female intellectual sorority focused on sisterhood, social change, and ethics.",
    relatedProject: "Lumina",
  },
  {
    filename: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=1600&q=80",
    title: "Intellect Night",
    category: "Events",
    commentary: "Weekly session focused on discussion and debate—engaging ideas seriously.",
  },
  {
    filename: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=1600&q=80",
    title: "City Outing",
    category: "Events",
    commentary: "Weekly urban exploration—observing the city, building context.",
  },
  {
    filename: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=1600&q=80",
    title: "The Studio Space",
    category: "Spaces",
    commentary: "Our main working space for focused creation, collaboration, and quiet work.",
  },
  {
    filename: "https://images.unsplash.com/photo-1568667256549-094345857637?w=1600&q=80",
    title: "Reading Room",
    category: "Spaces",
    commentary: "Curated library space for Alexandria reading circles and individual study.",
  },
]

export const categories: ShowcaseCategory[] = [
  "All",
  "Projects",
  "Events",
  "Spaces",
  "People",
]
