export interface Project {
  id: string
  title: string
  tagline: string
  description: string[]
  whatWeDo: string[]
  whoItsFor: string[]
  howToJoin: string[]
  incubating?: boolean
  icon: string
}

export const projects: Project[] = [
  {
    id: "creative-glade",
    title: "Creative Glade",
    tagline: "A curated space for original creative expression and output.",
    description: [
      "Creative Glade is the artistic heart of Medha. It is where writers, illustrators, designers, and multidisciplinary creators come together to produce original work that matters.",
      "We don't do hobby circles. Every member is expected to ship. Whether that's a zine, a short film, a poster series, or a body of written work, output is non-negotiable.",
    ],
    whatWeDo: [
      "Monthly creative sprints with structured deadlines",
      "Cross-disciplinary collaboration between writers and visual artists",
      "Public exhibitions and digital showcases",
      "Peer review sessions with honest, rigorous feedback",
    ],
    whoItsFor: [
      "Serious creators who want to move from consuming to producing",
      "Writers, illustrators, photographers, designers",
      "Anyone who treats craft as discipline, not decoration",
    ],
    howToJoin: [
      "Attend a Medha event or submit a portfolio sample",
      "Complete an intake conversation",
      "Receive a project lane assignment",
    ],
    icon: "Palette",
  },
  {
    id: "video-sans",
    title: "Video Sans",
    tagline: "A guild for serious creators.",
    description: [
      "Video Sans is where editors and visual storytellers refine craft through discipline and collaboration. It is not content farming. It is training the eye, the ear, and the sense of rhythm.",
      "We work on real projects. Output matters. Taste matters. Consistency matters.",
    ],
    whatWeDo: [
      "Structured editing assignments",
      "Premiere Pro and After Effects training sessions",
      "Collaborative documentaries and short-form reels",
      "Honest critique and technical breakdowns",
      "AI-assisted workflow experimentation",
    ],
    whoItsFor: [
      "Editors who want to move beyond trend-copying",
      "Creators who value craft over virality",
      "Those willing to accept critique and improve",
    ],
    howToJoin: [
      "Attend a session or submit sample work",
      "Complete a short technical review",
      "Commit to a production lane",
    ],
    icon: "Film",
  },
  {
    id: "platonic-dhaka",
    title: "Platonic Dhaka",
    tagline: "An intellectual narrative engine.",
    description: [
      "Platonic Dhaka translates first principles into public language. It clarifies culture, politics, and society through structured thinking and written output.",
      "This is not commentary. It is disciplined argument.",
    ],
    whatWeDo: [
      "Op-ed drafting sessions",
      "Structured debates and dialogues",
      "Concept workshops",
      "Short-form narrative pieces",
      "Intellectual framing for media",
    ],
    whoItsFor: [
      "Writers who value clarity over noise",
      "Thinkers who read before they speak",
      "Individuals willing to defend ideas rigorously",
    ],
    howToJoin: [
      "Submit a short written piece",
      "Participate in a dialogue session",
      "Receive editorial lane assignment",
    ],
    icon: "BookOpen",
  },
  {
    id: "alexandria",
    title: "Alexandria",
    tagline: "A structured lifelong learning system.",
    description: [
      "Alexandria is not about consuming information. It is about building intellectual architecture. Knowledge is organized, tested, and applied.",
      "Reading without structure is noise. We build systems.",
    ],
    whatWeDo: [
      "Reading circles across philosophy, politics, psychology, AI",
      "Structured note-making in Obsidian",
      "Curriculum tracks with levels",
      "Dialogue-based testing of understanding",
      "Cross-disciplinary mapping",
    ],
    whoItsFor: [
      "Individuals committed to long-term study",
      "Those willing to read primary texts",
      "People who want knowledge applied to life",
    ],
    howToJoin: [
      "Attend an open reading circle",
      "Complete intellectual profiling intake",
      "Enter a structured track",
    ],
    icon: "Library",
  },
  {
    id: "startup-club",
    title: "Startup Club",
    tagline: "A builders' discipline circle.",
    description: [
      "Startup Club is where ideas become systems. It is execution-focused. No fantasy entrepreneurship. Only building.",
      "We test. We ship. We refine.",
    ],
    whatWeDo: [
      "MVP design workshops",
      "Build sprints",
      "Financial model and pitch development",
      "Operational workflow mapping",
      "Peer accountability sessions",
    ],
    whoItsFor: [
      "Active builders",
      "Engineers and operators",
      "Founders serious about execution",
    ],
    howToJoin: [
      "Present an idea or active build",
      "Define time commitment",
      "Enter a sprint cycle",
    ],
    icon: "Rocket",
  },
  {
    id: "politikos-map",
    title: "Politikos Map",
    tagline: "Mapping power and institutions.",
    description: [
      "Politikos Map studies governance from structure to implementation. It examines how systems function in reality.",
      "Understanding precedes reform.",
    ],
    whatWeDo: [
      "Institutional mapping sessions",
      "Policy breakdown discussions",
      "Field research and documentation",
      "Civic explanatory content",
    ],
    whoItsFor: [
      "Students of governance",
      "Researchers and policy thinkers",
      "Those seeking structural clarity",
    ],
    howToJoin: [
      "Attend a mapping session",
      "Contribute a research note",
      "Join a thematic working group",
    ],
    icon: "Map",
  },
  {
    id: "dhaka-scouts",
    title: "Dhaka Scouts",
    tagline: "Rediscover the city through presence.",
    description: [
      "Dhaka Scouts walks the city without filters. It seeks lived experience beyond apps and narratives.",
      "We observe. We document. We reflect.",
    ],
    whatWeDo: [
      "Weekly walking explorations",
      "Conversations with locals",
      "Cultural documentation",
      "Photography and short films",
      "Post-walk reflection sessions",
    ],
    whoItsFor: [
      "Those who value attention and observation",
      "Creators interested in authentic experience",
      "Individuals willing to walk and listen",
    ],
    howToJoin: [
      "Attend a scout walk",
      "Share reflections",
      "Join documentation rotation",
    ],
    icon: "Compass",
  },
  {
    id: "prosno-show",
    title: "Prosno Show",
    tagline: "Public Socratic inquiry.",
    description: [
      "Prosno Show asks questions in public. It explores everyday assumptions without imposing conclusions.",
      "Dialogue over debate. Clarity over performance.",
    ],
    whatWeDo: [
      "Street interviews",
      "Long-form conversations",
      "Debate-style recordings",
      "Reel production",
      "Question design workshops",
    ],
    whoItsFor: [
      "Individuals comfortable with public dialogue",
      "Those who can ask and answer precisely",
      "People who value humility in discourse",
    ],
    howToJoin: [
      "Attend a recording session",
      "Participate in question design",
      "Join field or editorial team",
    ],
    icon: "Mic",
  },
  {
    id: "lumina",
    title: "Lumina",
    tagline: "An intellectual women's sorority.",
    description: [
      "Lumina gathers women committed to social responsibility, thought, and disciplined action. It is a sisterhood rooted in sincerity and strength.",
      "Empowerment without responsibility is noise.",
    ],
    whatWeDo: [
      "Reading circles and talks",
      "Women-led business and social initiative circles",
      "Social issue identification and solution design",
      "Content and narrative projects",
      "Retreats and bonding events",
    ],
    whoItsFor: [
      "Women seeking intellectual depth",
      "Small business owners and builders",
      "Those committed to collective uplift",
    ],
    howToJoin: [
      "Attend a Lumina gathering",
      "Complete intake discussion",
      "Enter a working circle",
    ],
    icon: "Sun",
  },
  {
    id: "fight-club",
    title: "Fight Club",
    tagline: "Power without corruption.",
    description: [
      "Fight Club unites disciplined physical training with principle-based knowledge. The body trains under the command of the soul.",
      "Strength must serve justice.",
    ],
    whatWeDo: [
      "Controlled grappling sessions",
      "Knowledge discussions",
      "Brotherhood building",
      "Character refinement",
    ],
    whoItsFor: [
      "Men seeking disciplined strength",
      "Those willing to restrain ego",
      "Individuals committed to consistency",
    ],
    howToJoin: [
      "Attend an introductory session",
      "Demonstrate physical and moral readiness",
      "Enter weekly training cycle",
    ],
    incubating: true,
    icon: "Swords",
  },
  {
    id: "principia",
    title: "Principia",
    tagline: "Unity in truth.",
    description: [
      "Principia recognizes that Truth is universal while intellect differs across individuals. It bridges metaphysical depth and practical clarity.",
      "Mentors guide. Members grow.",
    ],
    whatWeDo: [
      "Personalized intellectual guidance",
      "Assumption-hunting dialogues",
      "Structured mentorship",
      "Unity-centered discussions",
    ],
    whoItsFor: [
      "Serious truth-seekers",
      "Individuals willing to question themselves",
      "Those who value unity and care",
    ],
    howToJoin: [
      "Attend a Principia session",
      "Complete intellectual intake",
      "Receive mentor pairing",
    ],
    incubating: true,
    icon: "Lightbulb",
  },
]
